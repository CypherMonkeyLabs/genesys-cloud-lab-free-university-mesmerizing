import { DIAGRAMS, PORTS, renderDiagram } from "./diagrams.js";

export const PAGE_CITES = [
  ...new Set([
    ...DIAGRAMS.map((item) => item.url),
    ...PORTS.map((item) => item.url),
    "https://help.genesys.cloud/articles/about-predictive-engagement/",
    "https://help.genesys.cloud/announcements/genesys-cloud/deprecation-journey-outcomes/",
    "https://help.genesys.cloud/announcements/genesys-cloud/predictive-routing-supports-customer-defined-business-outcomes-with-custom-kpis/",
    "https://help.genesys.cloud/articles/create-an-oauth-client/",
    "https://help.genesys.cloud/articles/workforce-management/",
    "https://help.genesys.cloud/articles/work-with-forecasts/",
    "https://help.genesys.cloud/articles/about-genesys-cloud-for-salesforce/",
    "https://help.genesys.cloud/articles/about-genesys-cloud-for-zendesk/",
    "https://appfoundry.genesys.com/",
    "https://education.genesys.com/certification/cloud",
    "https://help.genesys.cloud/articles/genesys-cloud-ports-services/"
  ])
];

const HANDLERS = {
  atlas: showAtlas,
  ports: showPorts,
  game: showGame,
  map: showMap,
  sandbox: showSandbox,
  daily: showDaily,
  badges: showBadges,
  cheat: showCheat,
  roadmap: showRoadmap,
  security: showSecurity,
  career: showCareer,
  "whats-new": showNews,
  playbooks: showPlaybooks,
  deploy: showDeploy,
  architecture: showArchitecture,
  reporting: showReporting
};

export function mountPage(name, ctx) {
  const handler = HANDLERS[name];
  if (!handler) {
    ctx.root.innerHTML = `<h1>That wing is not on the floor</h1>`;
    return undefined;
  }
  return handler(ctx);
}

function showAtlas(ctx) {
  ctx.setTitle("Diagram atlas");
  const cards = DIAGRAMS.map((spec) => `
    <article class="card" id="d-${spec.id}">
      ${renderDiagram(spec)}
      <h3>${ctx.esc(spec.title)}</h3>
      <p>${ctx.esc(spec.caption)}</p>
      <p><a href="${ctx.esc(spec.url)}">${ctx.esc(spec.cite)}</a></p>
    </article>`).join("");
  ctx.root.innerHTML = `<p class="kicker">Atlas</p><h1>${DIAGRAMS.length} live diagrams</h1>
    <p>Each picture is a teaching sketch. The caption names the limit of the drawing. The link is the source.</p>
    <div class="grid">${cards}</div>`;
}

function showArchitecture(ctx) {
  ctx.setTitle("Architecture");
  const ids = ["core-region", "voice-path", "digital-path", "byoc-cloud", "byoc-prem", "packages"];
  ctx.root.innerHTML = `<p class="kicker">Architecture</p><h1>Where a conversation lives</h1>
    <p>An organization is born in one core AWS region. Satellite regions carry media and do not host the org. Voice enters through Genesys Cloud Voice or BYOC. Digital enters through Architect without a SIP trunk. CX packages stack voice, then digital and quality, then WEM, then Copilot.</p>
    ${gallery(ctx, ids)}
    <p class="uncertainty"><strong>Unverified as a network diagram. </strong>This is a teaching map. Region hosts other than the ones named in the interview drill stay on the regions article. This lab does not paste carrier IP addresses.</p>`;
}

function showPorts(ctx) {
  ctx.setTitle("Ports and protocols");
  const rows = PORTS.map((row) => `<tr><td>${ctx.esc(row.name)}</td><td>${ctx.esc(row.proto)}</td><td>${ctx.esc(row.port)}</td><td>${ctx.esc(row.dir)}</td><td>${ctx.esc(row.note)}</td><td><a href="${ctx.esc(row.url)}">${ctx.esc(row.source)}</a></td></tr>`).join("");
  ctx.root.innerHTML = `<p class="kicker">Mastery</p><h1>Ports and protocols</h1>
    <p>The firewall articles are the list that changes. This table keeps only the rows this lab opened. Signaling addresses and media addresses are different. Do not type an IP from memory.</p>
    ${one(ctx, "firewall")}
    ${one(ctx, "sip-ladder")}
    ${one(ctx, "sip-rtp")}
    <div class="scroll"><table><thead><tr><th>Use</th><th>Protocol</th><th>Port</th><th>Direction</th><th>What the page says</th><th>Source</th></tr></thead><tbody>${rows}</tbody></table></div>
    <p><a class="btn primary" href="#/game">Play the port game</a> <a class="btn" href="downloads/ports.html">Cheat sheet</a></p>`;
}

function showGame(ctx) {
  ctx.setTitle("Port game");
  const bank = [
    ["TLS trunk signaling commonly uses which TCP port?", "5061", ["5060", "443", "16384"], "The TLS article puts listeners on 5061."],
    ["UDP or TCP trunk signaling commonly uses which port?", "5060", ["5061", "443", "80"], "The transport article names 5060 for UDP and TCP."],
    ["Managed BYOC Cloud phones signal on which TCP port?", "8061", ["5060", "443", "3478"], "The VoIP phone article says 8061 for managed phones."],
    ["Unmanaged phone SIPS uses which TCP port?", "5061", ["8061", "80", "22"], "The same article says 5061 for unmanaged phones."],
    ["RTP and SRTP media use which UDP range?", "16384-65535", ["5060-5061", "80-443", "1024-2048"], "The phone article and the RTP FAQ name that range."],
    ["That media range must be open in which direction, per the FAQ?", "Outbound", ["Inbound only", "Neither", "ICMP only"], "The FAQ says outbound connections."],
    ["BYOC Cloud secure trunks use IPsec?", "No. SIP TLS and SRTP.", ["Yes", "Only on premises Edges", "Only for 911"], "The TLS specification says IPsec is not supported."],
    ["Signaling IPs and media IPs are:", "Different. SDP names the media.", ["Always the same host", "RFC 5737 addresses", "The login host"], "The public SIP article separates them."]
  ];
  let index = 0;
  let correct = 0;
  const root = ctx.root;
  const draw = () => {
    if (index >= bank.length) {
      const best = Math.max(ctx.state.progress.gameBest || 0, correct);
      ctx.state.progress.gameBest = best;
      ctx.saveProgress();
      root.innerHTML = `<p class="kicker">Port game</p><h1>${correct} of ${bank.length}</h1>
        <p>Best in this browser: ${best}. Seven or more earns the Port ace badge.</p>
        <div class="toolbar"><button class="btn primary" type="button" id="again">Play again</button><button class="btn" type="button" id="share">Download result card</button></div>
        <p><a href="#/ports">Back to the table</a></p>`;
      root.querySelector("#again").addEventListener("click", () => { index = 0; correct = 0; draw(); });
      root.querySelector("#share").addEventListener("click", () => shareCard({
        title: "Port mastery",
        score: `${correct} / ${bank.length}`,
        detail: "Genesys Cloud CX · Signal Floor"
      }));
      return;
    }
    const [q, answer, wrongs, why] = bank[index];
    const choices = shuffle([answer, ...wrongs], index);
    root.innerHTML = `<p class="kicker">Port game · ${index + 1} / ${bank.length}</p><h1>${ctx.esc(q)}</h1><div class="choice-grid"></div><p class="muted" id="why"></p>`;
    const grid = root.querySelector(".choice-grid");
    choices.forEach((choice) => {
      const btn = document.createElement("button");
      btn.className = "btn";
      btn.type = "button";
      btn.textContent = choice;
      btn.addEventListener("click", () => {
        const good = choice === answer;
        if (good) correct += 1;
        ctx.blip(good ? 660 : 220, 0.08);
        grid.querySelectorAll("button").forEach((el) => { el.disabled = true; });
        btn.classList.add(good ? "good" : "bad");
        root.querySelector("#why").textContent = (good ? "Correct. " : "Not this one. ") + why;
        const next = document.createElement("button");
        next.className = "btn primary";
        next.type = "button";
        next.textContent = "Next";
        next.addEventListener("click", () => { index += 1; draw(); });
        root.querySelector("#why").after(next);
      });
      grid.appendChild(btn);
    });
  };
  draw();
}

function showMap(ctx) {
  ctx.setTitle("Flow map");
  const nodes = [
    ["carrier", "Carrier / PSTN", "#/track/byoc", 70, 150],
    ["edge", "Edge", "#/track/edge", 190, 70],
    ["arch", "Architect", "#/track/architect", 320, 150],
    ["queue", "Queue", "#/track/queues", 460, 70],
    ["agent", "Agent", "#/track/acd", 600, 150],
    ["pe", "Web journey", "#/track/predictive", 190, 220],
    ["wem", "WEM", "#/track/wfm", 460, 220]
  ];
  const dots = nodes.map(([id, label, href, x, y]) => `
    <a href="${href}"><g class="map-node">
      <rect x="${x - 58}" y="${y - 22}" width="116" height="44" rx="14" fill="#d6f25c" />
      <text x="${x}" y="${y + 5}" text-anchor="middle" font-size="13" fill="#1a0c08">${ctx.esc(label)}</text>
    </g></a>`).join("");
  ctx.root.innerHTML = `<p class="kicker">Explorer</p><h1>Flow map</h1>
    <p>Click a node to open the track. The 3D floor is a different view.</p>
    <figure><svg class="diagram" viewBox="0 0 700 280" role="img" aria-label="Clickable map from the carrier through Architect to an agent, with the website and WEM beside the path.">
      <rect width="700" height="280" rx="20" fill="#10203a" />
      <path d="M70 150 H320 H600 M190 70 V150 M460 70 V220" stroke="#fff" stroke-dasharray="6 6" fill="none" class="dash" />
      ${dots}
    </svg></figure>
    <p><a class="btn" href="#/topology">Open the 3D floor</a> <a class="btn" href="#/sandbox">Build a call flow</a></p>`;
}

function showSandbox(ctx) {
  ctx.setTitle("Call flow sandbox");
  const actions = ["Play audio", "Collect digits", "Menu", "Call bot", "Data action", "Secure flow", "Transfer to queue", "Disconnect"];
  const flow = [];
  const root = ctx.root;
  const draw = () => {
    root.innerHTML = `<p class="kicker">Sandbox</p><h1>Build a learning flow</h1>
      <p>This is a vertical task list for practice. The JSON it exports is marked not importable. Architect in a live org is the product.</p>
      <div class="split"><div class="sandbox-list">${actions.map((name) => `<button class="action" type="button" data-add="${ctx.esc(name)}">${ctx.esc(name)}</button>`).join("")}</div>
      <div><h2>Task list</h2><ol id="tasks">${flow.map((name) => `<li>${ctx.esc(name)}</li>`).join("") || "<li>Empty. Add a way for the caller to leave.</li>"}</ol>
      <pre id="export"></pre>
      <button class="btn" type="button" id="clear">Clear</button></div></div>`;
    root.querySelectorAll("[data-add]").forEach((btn) => btn.addEventListener("click", () => {
      flow.push(btn.dataset.add);
      ctx.state.progress.sandbox = Math.max(ctx.state.progress.sandbox || 0, flow.length);
      ctx.saveProgress();
      ctx.blip(520, 0.05);
      draw();
    }));
    const blob = { lab: "signal-floor", importable: false, tasks: flow };
    root.querySelector("#export").textContent = JSON.stringify(blob, null, 2);
    root.querySelector("#clear").addEventListener("click", () => { flow.length = 0; draw(); });
  };
  draw();
}

function showDaily(ctx) {
  ctx.setTitle("Daily challenge");
  const bank = [
    ["A published flow is required because:", "A saved draft does not run", ["Drafts run at night", "Live Now publishes flows", "The Edge publishes them"], "Create a flow."],
    ["Conversation score treats one priority point as:", "60,000 milliseconds", ["One hour", "One ring", "Five skills"], "Create queues."],
    ["Bullseye allows up to:", "5 rings", ["50 rings", "200 rings", "1 ring"], "Bullseye routing overview."],
    ["Client credentials cannot call:", "/api/v2/users/me", ["/api/v2/routing/queues", "The login host", "OAuth"], "Client credentials guide."],
    ["Journey Outcomes were planned to end on:", "2026-06-29", ["2026-05-25", "2024-01-01", "Never"], "Deprecation announcement. Re-open it."],
    ["Short-term forecasts can:", "Generate a schedule", ["Replace Architect", "Open port 5061", "Last two years only"], "Work with forecasts."],
    ["BYOC emergency is provided by:", "Your carrier, not Genesys", ["A satellite region", "Agent Copilot", "AppFoundry"], "BYOC emergency article."],
    ["Web messaging tracking belongs on:", "The Messenger snippet", ["Both snippets at once", "The Edge", "A number plan"], "Migration article."]
  ];
  const today = new Date().toISOString().slice(0, 10);
  const index = [...today].reduce((sum, ch) => sum + ch.charCodeAt(0), 0) % bank.length;
  const [q, answer, wrongs, why] = bank[index];
  const choices = shuffle([answer, ...wrongs], index);
  const root = ctx.root;
  root.innerHTML = `<p class="kicker">UTC ${ctx.esc(today)}</p><h1>Daily challenge</h1><h2>${ctx.esc(q)}</h2><div class="choice-grid"></div>`;
  const grid = root.querySelector(".choice-grid");
  choices.forEach((choice) => {
    const btn = document.createElement("button");
    btn.className = "btn";
    btn.type = "button";
    btn.textContent = choice;
    btn.addEventListener("click", () => {
      const good = choice === answer;
      grid.querySelectorAll("button").forEach((el) => { el.disabled = true; });
      btn.classList.add(good ? "good" : "bad");
      const daily = ctx.state.progress.daily || { last: "", streak: 0 };
      if (daily.last !== today) {
        const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
        daily.streak = daily.last === yesterday ? daily.streak + 1 : 1;
        daily.last = today;
        daily.correct = good;
      }
      ctx.state.progress.daily = daily;
      ctx.saveProgress();
      root.insertAdjacentHTML("beforeend", `<p>${good ? "Correct." : "Not this one."} ${ctx.esc(why)}</p><p>Streak in this browser: ${daily.streak} UTC day${daily.streak === 1 ? "" : "s"}.</p><button class="btn" type="button" id="share">Result card</button>`);
      root.querySelector("#share").addEventListener("click", () => shareCard({
        title: "Daily challenge",
        score: good ? "Correct" : "Reviewed",
        detail: today + " · streak " + daily.streak
      }));
    });
    grid.appendChild(btn);
  });
}

function showBadges(ctx) {
  ctx.setTitle("Badges");
  const done = Object.values(ctx.state.progress.lessons || {}).filter((item) => item.done).length;
  const badges = [
    ["First light", done >= 1, "Finish a lesson quiz at 5 of 6 or complete its lab after that."],
    ["Five deep", done >= 5, "Finish five lessons."],
    ["Port ace", (ctx.state.progress.gameBest || 0) >= 7, "Score at least 7 on the port game."],
    ["Streak", ((ctx.state.progress.daily || {}).streak || 0) >= 2, "Answer the daily challenge on two UTC days in a row."],
    ["Sandbox", (ctx.state.progress.sandbox || 0) >= 4, "Add four actions in the call-flow sandbox."],
    ["Konami", Boolean(ctx.state.progress.konami), "The classic code, on this page."],
    ["Offline", Boolean(ctx.state.progress.offlineSaved), "Use Save for offline in the top bar or Settings."]
  ];
  ctx.root.innerHTML = `<p class="kicker">This browser</p><h1>Badges</h1>
    <p>${done} lessons finished. Badges stay in localStorage on this device.</p>
    <div class="grid">${badges.map(([name, on, how]) => `<article class="card badge"><div><h3>${ctx.esc(name)}</h3><p>${ctx.esc(how)}</p></div><em>${on ? "Earned" : "Locked"}</em></article>`).join("")}</div>`;
}

async function showCheat(ctx) {
  ctx.setTitle("Cheat codes");
  let catalog = { sheets: [] };
  try {
    const res = await fetch("downloads/catalog.json");
    if (res.ok) catalog = await res.json();
  } catch (err) {
    catalog = { sheets: [], error: true };
  }
  const cards = (catalog.sheets || []).map((sheet) => `<article class="card"><h3>${ctx.esc(sheet.title)}</h3><p>${ctx.esc(sheet.summary)}</p>
    <p><a href="${ctx.esc(sheet.html)}">HTML</a> · <a href="${ctx.esc(sheet.pdf)}">PDF</a> · <a href="${ctx.esc(sheet.png)}">PNG</a> · <a href="${ctx.esc(sheet.svg)}">SVG</a></p>
    <p class="muted">${(sheet.sources || []).map((url) => `<a href="${ctx.esc(url)}">${ctx.esc(hostOf(url))}</a>`).join(" · ")}</p></article>`).join("");
  ctx.root.innerHTML = `<p class="kicker">Downloads</p><h1>Cheat codes</h1>
    <p>One-page sheets, a printable flashcard deck, and a zip of this lab. Each file carries the lab footer. They summarize and link. They are not copies of the Resource Center.</p>
    <div class="toolbar"><a class="btn primary" href="downloads/flashcards.html">Printable flashcards</a><a class="btn" href="downloads/flashcards.json">Flashcards JSON</a><a class="btn" href="downloads/genesys-cx-offline-bundle.zip">Offline bundle</a></div>
    <div class="grid">${cards || "<p>The download catalog has not been generated.</p>"}</div>`;
}

function showRoadmap(ctx) {
  ctx.setTitle("Roadmap");
  ctx.root.innerHTML = `<p class="kicker">Study plan, not a vendor roadmap</p><h1>30 days on this floor</h1>
    <p>This sequence is the lab’s suggestion. Genesys does not publish it. Product changes for 2026 are on What’s new, with the pages named.</p>
    <ol class="ladder">
      <li><a href="#/track/foundations">Days 1–4 · Foundations</a></li>
      <li><a href="#/track/org">Days 5–8 · Organization and licensing</a></li>
      <li><a href="#/track/architect">Days 9–12 · Architect</a></li>
      <li><a href="#/track/acd">Days 13–16 · ACD and queues</a></li>
      <li><a href="#/track/byoc">Days 17–20 · BYOC, Edge, emergency, ports</a></li>
      <li><a href="#/track/wfm">Days 21–24 · WEM, quality, analytics</a></li>
      <li><a href="#/track/predictive">Days 25–27 · Predictive Engagement and AI</a></li>
      <li><a href="#/track/api">Days 28–30 · APIs, CRM, migration, interview</a></li>
    </ol>
    ${one(ctx, "certs-path")}
    <p><a class="btn" href="#/certs">Certification catalog</a> <a class="btn" href="#/whats-new">What’s new</a></p>`;
}

function showSecurity(ctx) {
  ctx.setTitle("Security");
  ctx.root.innerHTML = `<p class="kicker">Security and compliance</p><h1>Close the doors you actually have</h1>
    <p>Secure BYOC Cloud trunks use TLS 1.2 on TCP 5061 and SRTP. The TLS article says IPsec is not the method. Secure call flows keep payment digits out of the recording. Divisions plus role pairs are the permission boundary. Client-credentials tokens have no user, so <code>/api/v2/users/me</code> is the wrong call. The OAuth article dates Token Implicit Grant as deprecated after 25 May 2026.</p>
    <p>The About Predictive Engagement page points at Genesys Cloud and GDPR material. This lab does not restate that legal page. It also does not claim a certification such as SOC 2 or HIPAA; those words are absent here on purpose.</p>
    ${one(ctx, "srtp-lock")}
    ${one(ctx, "oauth")}
    <p><a href="https://help.genesys.cloud/articles/tls-trunk-transport-protocol-specification/">TLS trunk transport</a> ·
      <a href="https://help.genesys.cloud/articles/create-an-oauth-client/">OAuth client</a> ·
      <a href="https://developer.genesys.cloud/api/rest/authorization/use-client-credentials">Client credentials</a> ·
      <a href="https://help.genesys.cloud/articles/divisions-overview/">Divisions</a></p>
    <p class="uncertainty"><strong>Unverified. </strong>Compliance scope for a real organization is a contract and a questionnaire, not this page.</p>`;
}

function showCareer(ctx) {
  ctx.setTitle("Career paths");
  ctx.root.innerHTML = `<p class="kicker">Practice, not a job offer</p><h1>Paths through the tracks</h1>
    <div class="grid">
      <article class="card"><h3>Administrator</h3><p>Organization, queues, divisions, licensing. Then GC-GCP if the catalog still matches your job.</p><p><a href="#/track/org">Org</a> · <a href="#/certs">Certs</a></p></article>
      <article class="card"><h3>Flow designer</h3><p>Architect, bots, in-queue, secure flows. The Architect specialist row is a name, not a code this lab invents.</p><p><a href="#/track/architect">Architect</a> · <a href="#/sandbox">Sandbox</a></p></article>
      <article class="card"><h3>Telephony</h3><p>BYOC, Edge, number plans, emergency, and the port table.</p><p><a href="#/ports">Ports</a> · <a href="#/track/emergency">Emergency</a></p></article>
      <article class="card"><h3>WEM analyst</h3><p>Forecasts, schedules, quality, speech and text analytics.</p><p><a href="#/track/wfm">WFM</a> · <a href="#/reporting">Reporting</a></p></article>
      <article class="card"><h3>Developer</h3><p>Grants, the API explorer, AppFoundry. GC-GCD is the developer exam the catalog names.</p><p><a href="#/track/api">APIs</a> · <a href="#/studio/api">API studio</a></p></article>
    </div>
    <p><a class="btn primary" href="#/interview">Interview drill</a></p>
    <p class="muted">Nothing here promises an interview, a salary, or that a package includes a product. Read the overview and the catalog.</p>`;
}

function showNews(ctx) {
  ctx.setTitle("What’s new");
  ctx.root.innerHTML = `<p class="kicker">Read on 15 October 2026</p><h1>What’s new, as the pages said</h1>
    <article class="card"><h3>Journey Outcomes deprecation</h3><p>Announced 2026-05-18. Planned effective date 2026-06-29. After that date the announcement says outcomes are not processed, do not trigger action maps, and reporting goes away. Customer Outcomes is described as under development and will not include outcome scoring.</p><p><a href="https://help.genesys.cloud/announcements/genesys-cloud/deprecation-journey-outcomes/">Announcement</a></p></article>
    <article class="card"><h3>Predictive Routing custom outcomes</h3><p>A separate announcement describes a future framework for customer-defined KPIs, including metrics outside Genesys Cloud. It says existing predictive-routing configurations need no change until you migrate. This lab has not confirmed that the framework has shipped.</p><p><a href="https://help.genesys.cloud/announcements/genesys-cloud/predictive-routing-supports-customer-defined-business-outcomes-with-custom-kpis/">Announcement</a></p></article>
    <article class="card"><h3>Web chat toward web messaging</h3><p>The about page encourages web messaging. The migration article says remove the legacy tracking snippet when Messenger is tracking, or you double-count.</p><p><a href="https://help.genesys.cloud/articles/migrate-from-web-chat-to-web-messaging-for-digital-user-tracking-and-predictive-engagement/">Migration</a></p></article>
    <article class="card"><h3>Implicit grant</h3><p>The OAuth client article documents Token Implicit Grant as deprecated after 25 May 2026. Move user-facing apps to authorization code with PKCE.</p><p><a href="https://help.genesys.cloud/articles/create-an-oauth-client/">OAuth client</a></p></article>
    <p class="uncertainty"><strong>Unverified in a live org. </strong>Dates are the ones printed on those pages when this lab was built. If a page moved a date, the page wins.</p>
    ${one(ctx, "pe-sunset")}`;
}

function showPlaybooks(ctx) {
  ctx.setTitle("Playbooks");
  const rows = [
    ["No audio, flow still runs", "Media or the trunk. Architect Insights can be healthy while RTP is not.", "#/boss", "BYOC and the RTP FAQ"],
    ["Menu works, silence on hold", "The in-queue flow is unpublished or empty.", "#/track/architect", "In-queue flows"],
    ["Agent never alerts", "On Queue, utilization, skills, or a bullseye ring that has not opened.", "#/studio/routing", "Evaluation methods"],
    ["Screen pop dead, call fine", "The CRM embed failed. The queue did not.", "#/track/crm", "Salesforce and Zendesk about pages"],
    ["Website offers never fire", "Live Now is empty, the segment is too tight, or a schedule group hid the offer.", "#/track/predictive", "Messenger and action maps"],
    ["Emergency test", "Do not place a live emergency call as a demo. Confirm class, route, and owner.", "#/track/emergency", "BYOC emergency"]
  ];
  ctx.root.innerHTML = `<p class="kicker">Troubleshooting</p><h1>Playbooks</h1>
    <p>Synthetic logs in the boss incidents use RFC 5737 addresses. Start with the symptom, then open the track. Do not paste a lab address into a carrier ACL.</p>
    <div class="grid">${rows.map(([title, body, href, source]) => `<article class="card"><h3>${ctx.esc(title)}</h3><p>${ctx.esc(body)}</p><p><a href="${href}">Open</a> · ${ctx.esc(source)}</p></article>`).join("")}</div>
    ${one(ctx, "acd-gate")}`;
}

function showDeploy(ctx) {
  ctx.setTitle("Deployment");
  ctx.root.innerHTML = `<p class="kicker">Configuration walkthrough</p><h1>A first deployment, in order</h1>
    <p>This is a checklist of objects the existing lessons already teach. It is not a statement that every org needs every row.</p>
    <ol>
      <li><a href="#/track/org">Place the org in a core region. Create divisions and role pairs. Pick CX 1, 2, 3, or 4 on purpose.</a></li>
      <li><a href="#/track/byoc">For BYOC Cloud: location, trunk, outbound route, number plan. Match the transport on both ends.</a></li>
      <li><a href="#/track/edge">For premises: Edge group, phone trunk, site, and a failover site that actually has the resource.</a></li>
      <li><a href="#/ports">Open the signaling port you chose and outbound UDP 16384-65535. Copy IPs from the current regional article.</a></li>
      <li><a href="#/track/emergency">Name the emergency owner before the first DID. Class, route, and a test plan that is not a surprise 911 call.</a></li>
      <li><a href="#/track/architect">Publish the inbound flow and the in-queue flow. Add a bot only with a failure queue.</a></li>
      <li><a href="#/track/queues">Create the queue in a division, members, skills, wrap-up, service level.</a></li>
      <li><a href="#/track/wfm">If the package is CX 3 or higher: business unit, forecast, schedule.</a></li>
      <li><a href="#/track/predictive">If you sell on the web: one snippet, segments, an action map that survives the outcome deprecation.</a></li>
    </ol>
    ${one(ctx, "cutover")}`;
}

function showReporting(ctx) {
  ctx.setTitle("Reporting");
  ctx.root.innerHTML = `<p class="kicker">Reporting and analytics</p><h1>Three clocks</h1>
    <p>Queue service level is a percentage inside a target number of seconds, on the queue. Workforce intraday compares forecast to actual. Speech and text analytics reads the conversation after the channel has it. Predictive Engagement adds Live Now, visitor activity, and action-map performance. Outcome columns on that last set age out with the Journey Outcomes deprecation.</p>
    ${one(ctx, "sta-pipe")}
    ${one(ctx, "wfm-loop")}
    <p><a href="https://help.genesys.cloud/articles/speech-and-text-analytics-overview/">STA overview</a> ·
      <a href="https://help.genesys.cloud/articles/workforce-management/">Workforce management</a> ·
      <a href="https://help.genesys.cloud/articles/about-predictive-engagement/">Predictive Engagement</a> ·
      <a href="#/track/qm">Quality track</a></p>
    <p class="uncertainty"><strong>Unverified. </strong>The use case names action-map performance for web chat, content offers, and Architect flow. Confirm a web-messaging column on the live report before you call it missing.</p>`;
}

function gallery(ctx, ids) {
  return `<div class="grid">${ids.map((id) => one(ctx, id)).join("")}</div>`;
}

function one(ctx, id) {
  const spec = DIAGRAMS.find((item) => item.id === id);
  if (!spec) return "";
  return `<article class="card">${renderDiagram(spec)}<h3>${ctx.esc(spec.title)}</h3><p>${ctx.esc(spec.caption)}</p><p><a href="${ctx.esc(spec.url)}">${ctx.esc(spec.cite)}</a></p></article>`;
}

function hostOf(url) {
  try { return new URL(url).hostname; } catch (err) { return url; }
}

function shuffle(list, seed) {
  const copy = list.slice();
  let state = seed + 17;
  for (let i = copy.length - 1; i > 0; i -= 1) {
    state = (state * 1103515245 + 12345) % 2147483648;
    const j = state % (i + 1);
    const tmp = copy[i];
    copy[i] = copy[j];
    copy[j] = tmp;
  }
  return copy;
}

export function shareCard({ title, score, detail }) {
  const canvas = document.createElement("canvas");
  canvas.width = 1200;
  canvas.height = 630;
  const g = canvas.getContext("2d");
  g.fillStyle = "#07101c";
  g.fillRect(0, 0, 1200, 630);
  g.fillStyle = "#3ee0ff";
  g.fillRect(0, 0, 18, 630);
  g.fillStyle = "#f4fbff";
  g.font = "64px Georgia, serif";
  g.fillText("Signal Floor", 64, 140);
  g.font = "42px Georgia, serif";
  g.fillText(title, 64, 230);
  g.fillStyle = "#d6f25c";
  g.font = "80px Georgia, serif";
  g.fillText(score, 64, 360);
  g.fillStyle = "#b7c6e6";
  g.font = "28px sans-serif";
  g.fillText(detail, 64, 440);
  g.fillText("https://cyphermonkeylabs.com", 64, 540);
  const link = document.createElement("a");
  link.href = canvas.toDataURL("image/png");
  link.download = "signal-floor-result.png";
  link.click();
}
